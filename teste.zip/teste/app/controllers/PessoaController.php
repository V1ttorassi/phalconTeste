<?php
namespace ;

use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;
use Pessoa;

class PessoaController extends ControllerBase
{
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Searches for pessoa
     */
    public function searchAction()
    {
        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, 'Pessoa', $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = [];
        }
        $parameters["order"] = "id";

        $pessoa = Pessoa::find($parameters);
        if (count($pessoa) == 0) {
            $this->flash->notice("The search did not find any pessoa");

            $this->dispatcher->forward([
                "controller" => "pessoa",
                "action" => "index"
            ]);

            return;
        }

        $paginator = new Paginator([
            'data' => $pessoa,
            'limit'=> 10,
            'page' => $numberPage
        ]);

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a pessoa
     *
     * @param string $id
     */
    public function editAction($id)
    {
        if (!$this->request->isPost()) {

            $pessoa = Pessoa::findFirstByid($id);
            if (!$pessoa) {
                $this->flash->error("pessoa was not found");

                $this->dispatcher->forward([
                    'controller' => "pessoa",
                    'action' => 'index'
                ]);

                return;
            }

            $this->view->id = $pessoa->id;

            $this->tag->setDefault("id", $pessoa->id);
            $this->tag->setDefault("nome", $pessoa->nome);
            $this->tag->setDefault("idade", $pessoa->idade);
            $this->tag->setDefault("peso", $pessoa->peso);
            
        }
    }

    /**
     * Creates a new pessoa
     */
    public function createAction()
    {
        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'index'
            ]);

            return;
        }

        $pessoa = new Pessoa();
        $pessoa->nome = $this->request->getPost("nome");
        $pessoa->idade = $this->request->getPost("idade");
        $pessoa->peso = $this->request->getPost("peso");
        

        if (!$pessoa->save()) {
            foreach ($pessoa->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'new'
            ]);

            return;
        }

        $this->flash->success("pessoa was created successfully");

        $this->dispatcher->forward([
            'controller' => "pessoa",
            'action' => 'index'
        ]);
    }

    /**
     * Saves a pessoa edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'index'
            ]);

            return;
        }

        $id = $this->request->getPost("id");
        $pessoa = Pessoa::findFirstByid($id);

        if (!$pessoa) {
            $this->flash->error("pessoa does not exist " . $id);

            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'index'
            ]);

            return;
        }

        $pessoa->nome = $this->request->getPost("nome");
        $pessoa->idade = $this->request->getPost("idade");
        $pessoa->peso = $this->request->getPost("peso");
        

        if (!$pessoa->save()) {

            foreach ($pessoa->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'edit',
                'params' => [$pessoa->id]
            ]);

            return;
        }

        $this->flash->success("pessoa was updated successfully");

        $this->dispatcher->forward([
            'controller' => "pessoa",
            'action' => 'index'
        ]);
    }

    /**
     * Deletes a pessoa
     *
     * @param string $id
     */
    public function deleteAction($id)
    {
        $pessoa = Pessoa::findFirstByid($id);
        if (!$pessoa) {
            $this->flash->error("pessoa was not found");

            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'index'
            ]);

            return;
        }

        if (!$pessoa->delete()) {

            foreach ($pessoa->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "pessoa",
                'action' => 'search'
            ]);

            return;
        }

        $this->flash->success("pessoa was deleted successfully");

        $this->dispatcher->forward([
            'controller' => "pessoa",
            'action' => "index"
        ]);
    }

}
